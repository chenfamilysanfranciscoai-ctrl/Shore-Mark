-- =============================================================================
-- Shoremark "Spot a Need": database, security rules and photo storage.
-- Paste this whole file into Supabase > SQL Editor > New query > Run. It is safe
-- to run more than once.
--
-- How the safety works:
--   * The public (anon) key can ONLY (1) add a report that starts as 'pending'
--     and (2) read the public_reports view, which shows approved reports only,
--     with the coordinates rounded to about 100 m.
--   * Nobody can read pending reports, contact details or reviewer notes except
--     a logged-in admin (a row in the admins table).
-- =============================================================================

create table if not exists public.admins (
  user_id uuid primary key references auth.users(id) on delete cascade
);
alter table public.admins enable row level security;   -- no policies: not readable through the API

create or replace function public.is_admin() returns boolean
language sql security definer stable set search_path = public as $$
  select exists (select 1 from public.admins where user_id = auth.uid());
$$;

create or replace function public.valid_photo_paths(p text[]) returns boolean
language sql immutable as $$
  select coalesce(bool_and(x ~ '^[0-9a-f-]{36}\.jpg$'), false) from unnest(p) as x;
$$;

create table if not exists public.reports (
  id            uuid primary key default gen_random_uuid(),
  created_at    timestamptz not null default now(),
  causes        text[] not null,
  description   text not null,
  place_name    text not null,
  lat           double precision not null,
  lng           double precision not null,
  photo_paths   text[] not null,
  status        text not null default 'pending',
  claimed_by    text,
  reviewer_note text,
  reviewed_at   timestamptz,
  constraint causes_valid  check (causes <@ array['litter','habitat','invasive','dumping','erosion','water','other']
                                  and cardinality(causes) between 1 and 4),
  constraint desc_len      check (char_length(description) between 10 and 600),
  constraint place_len     check (char_length(place_name) between 2 and 120),
  constraint coords_ok     check (lat between 32 and 49.5 and lng between -125 and -114),
  constraint photos_ok     check (cardinality(photo_paths) between 1 and 3 and public.valid_photo_paths(photo_paths)),
  constraint status_valid  check (status in ('pending','approved','rejected','resolved')),
  constraint claimed_len   check (claimed_by is null or char_length(claimed_by) <= 120)
);

-- Anti-flood: stop accepting new reports while 100 or more are waiting for review.
create or replace function public.limit_pending() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if (select count(*) from public.reports where status = 'pending') >= 100 then
    raise exception 'Too many reports are waiting for review right now. Please try again later.';
  end if;
  return new;
end $$;
drop trigger if exists limit_pending_trg on public.reports;
create trigger limit_pending_trg before insert on public.reports
  for each row execute function public.limit_pending();

alter table public.reports enable row level security;
revoke all on public.reports from anon, authenticated;
grant insert on public.reports to anon, authenticated;
grant select, update, delete on public.reports to authenticated;

drop policy if exists "anyone can submit a pending report" on public.reports;
create policy "anyone can submit a pending report" on public.reports
  for insert to anon, authenticated
  with check (status = 'pending' and claimed_by is null and reviewer_note is null and reviewed_at is null);

drop policy if exists "admin reads reports" on public.reports;
create policy "admin reads reports"   on public.reports for select to authenticated using (public.is_admin());
drop policy if exists "admin updates reports" on public.reports;
create policy "admin updates reports" on public.reports for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "admin deletes reports" on public.reports;
create policy "admin deletes reports" on public.reports for delete to authenticated using (public.is_admin());

-- What the public Needs Board is allowed to see: approved or cleaned-up reports,
-- rounded coordinates, nothing else.
create or replace view public.public_reports as
  select id, created_at, causes, description, place_name,
         round(lat::numeric, 3)::float8 as lat,
         round(lng::numeric, 3)::float8 as lng,
         photo_paths, claimed_by, status
  from public.reports
  where status in ('approved', 'resolved');
revoke all on public.public_reports from anon, authenticated;
grant select on public.public_reports to anon, authenticated;

-- "My group could host an event here": organizations leave contact details that
-- only an admin can read.
create or replace function public.report_is_public(rid uuid) returns boolean
language sql security definer stable set search_path = public as $$
  select exists (select 1 from public.reports where id = rid and status = 'approved');
$$;

create table if not exists public.host_interest (
  id            uuid primary key default gen_random_uuid(),
  created_at    timestamptz not null default now(),
  report_id     uuid not null references public.reports(id) on delete cascade,
  org_name      text not null,
  contact_name  text not null,
  contact_email text not null,
  message       text,
  constraint org_len   check (char_length(org_name) between 2 and 120),
  constraint name_len  check (char_length(contact_name) between 2 and 120),
  constraint email_ok  check (contact_email ~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' and char_length(contact_email) <= 200),
  constraint msg_len   check (message is null or char_length(message) <= 500)
);
alter table public.host_interest enable row level security;
revoke all on public.host_interest from anon, authenticated;
grant insert on public.host_interest to anon, authenticated;
grant select, delete on public.host_interest to authenticated;

drop policy if exists "anyone can offer to host" on public.host_interest;
create policy "anyone can offer to host" on public.host_interest
  for insert to anon, authenticated with check (public.report_is_public(report_id));
drop policy if exists "admin reads interest" on public.host_interest;
create policy "admin reads interest"   on public.host_interest for select to authenticated using (public.is_admin());
drop policy if exists "admin deletes interest" on public.host_interest;
create policy "admin deletes interest" on public.host_interest for delete to authenticated using (public.is_admin());

-- Photo storage: JPEGs only, 3 MB max, random file names. Anyone can upload;
-- only an admin can delete.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('report-photos', 'report-photos', true, 3145728, array['image/jpeg'])
on conflict (id) do update set public = true, file_size_limit = 3145728, allowed_mime_types = array['image/jpeg'];

drop policy if exists "anyone can upload report photos" on storage.objects;
create policy "anyone can upload report photos" on storage.objects
  for insert to anon, authenticated
  with check (bucket_id = 'report-photos' and name ~ '^[0-9a-f-]{36}\.jpg$');

drop policy if exists "admin deletes report photos" on storage.objects;
create policy "admin deletes report photos" on storage.objects
  for delete to authenticated using (bucket_id = 'report-photos' and public.is_admin());
